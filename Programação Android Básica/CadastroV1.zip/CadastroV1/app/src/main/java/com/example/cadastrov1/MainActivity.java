package com.example.cadastrov1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtNome;
    EditText edtEmail;
    EditText edtFone;
    EditText edtEndereco;
    Button btnCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNome = findViewById(R.id.edtNome);
        edtEmail = findViewById(R.id.edtEmail);
        edtFone = findViewById(R.id.edtFone);
        edtEndereco = findViewById(R.id.edtEndereco);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edtNome.getText().toString().isEmpty() ||
                   edtEmail.getText().toString().isEmpty() ||
                   edtFone.getText().toString().isEmpty() ||
                   edtEndereco.getText().toString().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Preencha todos os campos!", Toast.LENGTH_LONG).show();
                } else {
                    String nome = edtNome.getText().toString();
                    String email = edtEmail.getText().toString();
                    String fone = edtFone.getText().toString();
                    String endereco = edtEndereco.getText().toString();

                    // Bundle para armazenar dados que irão para outra activity
                    Bundle bundle = new Bundle();
                    bundle.putString("nome", nome);
                    bundle.putString("email", email);
                    bundle.putString("fone", fone);
                    bundle.putString("endereco", endereco);

                    Intent intent = new Intent(MainActivity.this, CadastroActivity.class);
                    intent.putExtras(bundle);

                    // Método para iniciar outra activity
                    startActivity(intent);
                }
            }
        });
    }
}
