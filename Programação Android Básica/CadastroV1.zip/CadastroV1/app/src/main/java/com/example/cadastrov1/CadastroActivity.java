package com.example.cadastrov1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class CadastroActivity extends AppCompatActivity {

    TextView txtNome;
    TextView txtEmail;
    TextView txtFone;
    TextView txtEndereco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        txtNome = findViewById(R.id.txtNome);
        txtEmail = findViewById(R.id.txtEmail);
        txtFone = findViewById(R.id.txtFone);
        txtEndereco = findViewById(R.id.txtEndereco);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        String nome = bundle.getString("nome", "");
        String email = bundle.getString("email", "");
        String fone = bundle.getString("fone", "");
        String endereco = bundle.getString("endereco", "");

        txtNome.setText(nome);
        txtEmail.setText(email);
        txtFone.setText(fone);
        txtEndereco.setText(endereco);
    }
}
