package com.example.cadastrotarefas;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class TarefasHelper extends SQLiteOpenHelper {

    public static final String DB = "tarefas_db";
    public static final String TABELA = "tarefa";

    public static final String ID = "id_tarefa";
    public static final String TAREFA = "tarefa";
    public static final String PRIORIDADE = "prioridade";
    public static final String TEMPO = "tempo";

    public static final int VERSAO = 1;

    public TarefasHelper(@Nullable Context context) {
        super(context, DB, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "CREATE TABLE IF NOT EXISTS " +
                TABELA + " ( " +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TAREFA + " VARCHAR, " +
                PRIORIDADE + " VARCHAR, " +
                TEMPO + " VARCHAR);";
        sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE " + TABELA);
        onCreate(sqLiteDatabase);
    }
}
