package com.example.cadastrotarefas;

import java.util.ArrayList;

public class ListaTarefas {

    private static ArrayList<Tarefa> listaTarefas = new ArrayList<>();

    public static void addTarefa(Tarefa tarefa){
        listaTarefas.add(tarefa);
    }

    public static ArrayList<Tarefa> getLista(){
        return listaTarefas;
    }

    public static Tarefa getTarefa(int index){
        return listaTarefas.get(index);
    }

}
