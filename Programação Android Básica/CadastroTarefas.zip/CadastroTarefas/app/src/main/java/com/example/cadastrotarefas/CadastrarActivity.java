package com.example.cadastrotarefas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastrarActivity extends AppCompatActivity {

    EditText edtTarefa;
    EditText edtPrioridade;
    EditText edtTempo;
    Button btnSalvar;

    String tarefa;
    String prioridade;
    String tempo;
    String msg;
    TarefasDAO tarefasDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);

        edtTarefa = findViewById(R.id.edtTarefa);
        edtPrioridade = findViewById(R.id.edtPrioridade);
        edtTempo = findViewById(R.id.edtTempo);
        btnSalvar = findViewById(R.id.btnSalvar);

        tarefasDAO = new TarefasDAO(CadastrarActivity.this);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!edtTarefa.getText().toString().equals("") &&
                   !edtPrioridade.getText().toString().equals("") &&
                   !edtTempo.getText().toString().equals("")){

                    tarefa = edtTarefa.getText().toString();
                    prioridade = edtPrioridade.getText().toString();
                    tempo = edtTempo.getText().toString();

                    Tarefa t = new Tarefa(0, tarefa, prioridade, tempo);

                    try{
                        if(tarefasDAO.salvarTarefa(t)){
                            msg = "Tarefa cadastrada com sucesso.";
                        } else {
                            msg = "Erro ao cadastrar tarefa.";
                        }
                    } catch (Exception e){
                        msg = "Erro ao conectar com o banco de dados.";
                    }

                    Toast.makeText(CadastrarActivity.this, msg, Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(CadastrarActivity.this, MainActivity.class));
                } else {
                    Toast.makeText(CadastrarActivity.this, "Preencha todos os campos.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
