package com.example.cadastrotarefas;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TarefasAdapter extends RecyclerView.Adapter {

    private ArrayList<Tarefa> listaTarefas;
    private Context context;

    public TarefasAdapter(ArrayList<Tarefa> listaTarefas, Context context) {
        this.listaTarefas = listaTarefas;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.celula_tarefa, parent, false);
        TarefasHolder tarefasHolder = new TarefasHolder(view);
        return tarefasHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        TarefasHolder tarefasHolder = (TarefasHolder) holder;
        tarefasHolder.txtTarefa.setText(listaTarefas.get(position).getTarefa());
        tarefasHolder.txtPrioridade.setText(listaTarefas.get(position).getPrioridade());

        tarefasHolder.txtTarefa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent detalhes = new Intent(context, DetalhesActivity.class);
                detalhes.putExtra("index", position);
                detalhes.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(detalhes);
            }
        });
        tarefasHolder.txtPrioridade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent detalhes = new Intent(context, DetalhesActivity.class);
                detalhes.putExtra("index", position);
                detalhes.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(detalhes);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaTarefas.size();
    }
}
