package com.example.cadastrotarefas;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class TarefasGateway {

    private static TarefasGateway gateway;

    private SQLiteDatabase db;

    public TarefasGateway(Context context){
        TarefasHelper helper = new TarefasHelper(context);
        db = helper.getWritableDatabase();
    }

    public static TarefasGateway getInstance(Context context){
        if (gateway == null){
            gateway = new TarefasGateway(context);
        }
        return gateway;
    }

    public SQLiteDatabase getDatabase(){
        return this.db;
    }

}
