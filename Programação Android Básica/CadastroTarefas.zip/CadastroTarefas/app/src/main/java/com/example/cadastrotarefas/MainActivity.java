package com.example.cadastrotarefas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnCadastrar;
    RecyclerView rclTarefas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCadastrar = findViewById(R.id.btnCadastrar);
        rclTarefas = findViewById(R.id.rclTarefas);

        if(ListaTarefas.getLista().size() > 0){
            ListaTarefas.getLista().clear();
        }

        TarefasDAO tarefasDAO = new TarefasDAO(MainActivity.this);

        try{
            tarefasDAO.listarTarefas();
        }catch (Exception e){
            e.printStackTrace();
        }

        TarefasAdapter tarefasAdapter = new TarefasAdapter(ListaTarefas.getLista(), MainActivity.this);
        RecyclerView.LayoutManager meuLayout = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false);

        rclTarefas.setAdapter(tarefasAdapter);
        rclTarefas.setLayoutManager(meuLayout);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, CadastrarActivity.class));
            }
        });

    }
}
