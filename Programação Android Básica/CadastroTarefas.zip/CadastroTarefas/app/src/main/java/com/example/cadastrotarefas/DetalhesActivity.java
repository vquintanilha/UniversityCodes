package com.example.cadastrotarefas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DetalhesActivity extends AppCompatActivity {

    TextView txtVerTarefa;
    TextView txtVerPrioridade;
    TextView txtVerTempo;
    Button btnConcluir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);

        txtVerTarefa = findViewById(R.id.txtVerTarefa);
        txtVerPrioridade = findViewById(R.id.txtVerPrioridade);
        txtVerTempo = findViewById(R.id.txtVerTempo);
        btnConcluir = findViewById(R.id.btnConcluir);

        Intent intent = getIntent();
        int index = intent.getIntExtra("index", -1);

        if(index == -1){
            Toast.makeText(this, "Erro ao carregar detalhes da tarefa.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(DetalhesActivity.this, MainActivity.class));
        } else {
            final Tarefa t = ListaTarefas.getTarefa(index);
            txtVerTarefa.setText("Tarefa: " + t.getTarefa());
            txtVerPrioridade.setText("Prioridade: " + t.getPrioridade());
            txtVerTempo.setText("Tempo Estimado: " + t.getTempo());

            btnConcluir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TarefasDAO tarefasDAO = new TarefasDAO(DetalhesActivity.this);
                    if(tarefasDAO.excluirTarefa(t.getId())){
                        Toast.makeText(DetalhesActivity.this, "Tarefa concluída com sucesso.", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(DetalhesActivity.this, MainActivity.class));
                    } else {
                        Toast.makeText(DetalhesActivity.this, "Erro ao concluir a tarefa.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}
