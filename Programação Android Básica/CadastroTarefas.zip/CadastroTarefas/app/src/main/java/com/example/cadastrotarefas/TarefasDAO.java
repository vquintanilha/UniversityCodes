package com.example.cadastrotarefas;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class TarefasDAO {

    private TarefasGateway gateway;

    public TarefasDAO(Context context){
        gateway = TarefasGateway.getInstance(context);
    }

    public boolean salvarTarefa(Tarefa t){
        ContentValues values = new ContentValues();
        values.put(TarefasHelper.TAREFA, t.getTarefa());
        values.put(TarefasHelper.PRIORIDADE, t.getPrioridade());
        values.put(TarefasHelper.TEMPO, t.getTempo());

        long result = gateway.getDatabase().insert(TarefasHelper.TABELA, null, values);

        if (result > 0){
            return true;
        }
        return false;
    }

    public void listarTarefas(){
        String sql = "SELECT * FROM " + TarefasHelper.TABELA;
        Cursor cursor = gateway.getDatabase().rawQuery(sql, null);
        try{
            cursor.moveToFirst();
            while(cursor != null){
                int id = cursor.getInt(cursor.getColumnIndex(TarefasHelper.ID));
                String tarefa = cursor.getString(cursor.getColumnIndex(TarefasHelper.TAREFA));
                String prioridade = cursor.getString(cursor.getColumnIndex(TarefasHelper.PRIORIDADE));
                String tempo = cursor.getString(cursor.getColumnIndex(TarefasHelper.TEMPO));
                Tarefa t = new Tarefa(id, tarefa, prioridade, tempo);
                ListaTarefas.addTarefa(t);
                cursor.moveToNext();
            }
            cursor.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public boolean excluirTarefa(int id){
        String where = TarefasHelper.ID + " = ?";
        String[] args = {String.valueOf(id)};

        long result = gateway.getDatabase().delete(TarefasHelper.TABELA, where, args);

        if (result > 0){
            return true;
        }
        return false;
    }

}
