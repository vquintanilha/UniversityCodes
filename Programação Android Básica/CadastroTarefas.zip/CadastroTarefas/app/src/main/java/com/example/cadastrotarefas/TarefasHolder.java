package com.example.cadastrotarefas;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class TarefasHolder extends RecyclerView.ViewHolder {

    TextView txtTarefa;
    TextView txtPrioridade;

    public TarefasHolder(@NonNull View itemView) {
        super(itemView);
        this.txtTarefa = itemView.findViewById(R.id.txtTarefa);
        this.txtPrioridade = itemView.findViewById(R.id.txtPrioridade);
    }
}
