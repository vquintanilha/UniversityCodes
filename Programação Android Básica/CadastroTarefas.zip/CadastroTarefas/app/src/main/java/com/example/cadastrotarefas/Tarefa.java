package com.example.cadastrotarefas;

public class Tarefa {

    private int id;
    private String tarefa;
    private String prioridade;
    private String tempo;

    public Tarefa(int id, String tarefa, String prioridade, String tempo) {
        this.id = id;
        this.tarefa = tarefa;
        this.prioridade = prioridade;
        this.tempo = tempo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTarefa() {
        return tarefa;
    }

    public void setTarefa(String tarefa) {
        this.tarefa = tarefa;
    }

    public String getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(String prioridade) {
        this.prioridade = prioridade;
    }

    public String getTempo() {
        return tempo;
    }

    public void setTempo(String tempo) {
        this.tempo = tempo;
    }
}
