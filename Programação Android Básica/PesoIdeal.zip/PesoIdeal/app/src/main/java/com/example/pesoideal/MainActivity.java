package com.example.pesoideal;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtAltura;
    TextView txtResposta;
    Button btnCalcular;
    int k = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtAltura = findViewById(R.id.edtAltura);
        txtResposta = findViewById(R.id.txtResposta);
        btnCalcular = findViewById(R.id.btnCalcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeKeyboard();
                if(edtAltura.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Informe a altura!", Toast.LENGTH_LONG).show();
                }
                else {
                    int altura = Integer.parseInt(edtAltura.getText().toString());
                    float peso = (altura - 100) - ((altura - 150) / k);
                    txtResposta.setText("Peso Ideal: " + peso + " Kg");
                    edtAltura.setText("");
                }
            }
        });
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.rdbHomem:
                if (checked)
                    k = 4;
                break;
            case R.id.rdbMulher:
                if (checked)
                    k = 2;
                break;
        }
    }
}
