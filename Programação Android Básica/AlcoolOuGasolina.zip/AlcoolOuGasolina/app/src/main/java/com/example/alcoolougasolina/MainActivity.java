package com.example.alcoolougasolina;

import android.content.Context;
import android.renderscript.ScriptGroup;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    EditText edtValor;
    Button   btnVerificar;
    TextView txtResposta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // criar a referencia com os elementos de interface
        edtValor = findViewById(R.id.edtValor);
        btnVerificar = findViewById(R.id.btnVerificar);
        txtResposta = findViewById(R.id.txtResposta);

        btnVerificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeKeyboard();
                if(edtValor.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Digite o valor da gasolina!", Toast.LENGTH_LONG).show();
                } else {
                    float valor = Float.parseFloat(edtValor.getText().toString());
                    float resposta = valor * 0.7f;

                    String valorFinal = String.format(Locale.FRANCE, "%.2f", resposta);

                    txtResposta.setText("Abasteça no àlcool se ele estiver custando até: R$ " + valorFinal);
                    edtValor.setText("");
                }
            }
        });
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
