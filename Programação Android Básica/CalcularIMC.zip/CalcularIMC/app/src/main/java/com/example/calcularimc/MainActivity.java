package com.example.calcularimc;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtPeso;
    EditText edtAltura;
    Button btnCalcular;
    TextView txtResposta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtPeso     = findViewById(R.id.edtPeso);
        edtAltura   = findViewById(R.id.edtAltura);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtResposta = findViewById(R.id.txtResposta);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeKeyboard();
                if(edtPeso.getText().toString().isEmpty() || edtAltura.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Digite o seu peso e a sua altura!", Toast.LENGTH_LONG).show();
                } else {
                    float peso = Float.parseFloat(edtPeso.getText().toString());
                    float altura = Float.parseFloat(edtAltura.getText().toString());

                    float imc = peso / (altura * altura);

                    String resposta;

                    if(imc < 17){
                        resposta = imc + ": Muito abaixo do peso";
                    } else if(imc < 18.5f) {
                        resposta = imc + ": Abaixo do peso";
                    } else if(imc < 25) {
                        resposta = imc + ": Peso normal";
                    } else if(imc < 35) {
                        resposta = imc + ": Obesidade I";
                    } else if(imc < 40) {
                        resposta = imc + ": Obesidade II (severa)";
                    } else {
                        resposta = imc + ": Obesidade III (mórbida)";
                    }

                    txtResposta.setText(resposta);

                    edtPeso.getText().clear();
                    edtAltura.getText().clear();
                }
            }
        });
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
