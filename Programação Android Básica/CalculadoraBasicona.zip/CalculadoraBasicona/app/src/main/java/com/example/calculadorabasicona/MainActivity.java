package com.example.calculadorabasicona;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    EditText edtN1;
    EditText edtN2;
    TextView txtResultado;
    Button btnAdi;
    Button btnSub;
    Button btnMult;
    Button btnDiv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtN1 = findViewById(R.id.edtN1);
        edtN2 = findViewById(R.id.edtN2);
        txtResultado = findViewById(R.id.txtResultado);
        btnAdi = findViewById(R.id.btnAdi);
        btnSub = findViewById(R.id.btnSub);
        btnMult = findViewById(R.id.btnMult);
        btnDiv = findViewById(R.id.btnDiv);
    }

    public void Calcular(View btn) {
        if(edtN1.getText().toString().isEmpty() || edtN2.getText().toString().isEmpty()) {
            Toast.makeText(this, "Informe ambos os valores!", Toast.LENGTH_LONG).show();
        } else {
            float n1 = Float.parseFloat(edtN1.getText().toString());
            float n2 = Float.parseFloat(edtN2.getText().toString());

            Button btnOp = (Button) btn;
            float result = 0;

            switch(btnOp.getId()){
                case R.id.btnAdi:
                    result = n1 + n2;
                    break;

                case R.id.btnSub:
                    result = n1 - n2;
                    break;

                case R.id.btnMult:
                    result = n1 * n2;
                    break;

                case R.id.btnDiv:
                    if(n2 == 0){
                        Toast.makeText(this, "Divisão por Zero!", Toast.LENGTH_LONG).show();
                    } else {
                        result = n1 / n2;
                    }
                    break;
            }

            txtResultado.setText("Resultado = " + result);
            edtN1.setText("");
            edtN2.setText("");
        }
    }
}
