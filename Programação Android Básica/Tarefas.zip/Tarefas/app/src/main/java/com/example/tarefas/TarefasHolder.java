package com.example.tarefas;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class TarefasHolder extends RecyclerView.ViewHolder {

   // quais os campos que cada célula irá exibir no RecyclerView?
    TextView txtTarefa; // o nome da tarefa
    TextView txtPrioridade; // e sua prioridade

    public TarefasHolder(@NonNull View itemView) {
        super(itemView); // necessário, já que estamos herdando a classe ViewHolder

        // abaixo, estamos dizendo que cada célula terá seu próprio campo de texto
        // para agrigar o nome da tarefa, e outro para sua prioridade
        // (basicamente, cada célula terão os atributos definidos acima conversando
        // com seus elementos de interface - as duas TextViews, no caso)
        txtTarefa = itemView.findViewById(R.id.txtTarefa);
        txtPrioridade= itemView.findViewById(R.id.txtPrioridade);
    }
}
