package com.example.tarefas;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class TarefasDAO {

    private DBGateway gateway;

    public TarefasDAO(Context context) {
        this.gateway = DBGateway.getInstace(context);
    }

    public boolean salverTarefa(Tarefa t){



        // Criar ContentValues (similar a um Bundle)
        ContentValues values = new ContentValues();

        // armazenar dados do objeto 't' no objeto 'values'
        // argumentos: nome do campo, valor a ser salvo
        values.put(DBHelper.TAREFA, t.getTarefa());
        values.put(DBHelper.PRIORIDADE, t.getPrioridade());

        values.put(DBHelper.TEMPO, t.getTempoEstimado());
        long result = 0;
        try {

            result = gateway.getDataBase().insert(
                    DBHelper.TABELA, null, values);

        }catch (Exception e){
            e.printStackTrace();
        }

        if(result > 0){
            return true;
        }

        return false;
    }

    public void getTarefas(){

        String sql = "SELECT * FROM " + DBHelper.TABELA;

        try{
            Cursor cursor = gateway.getDataBase().rawQuery(sql, null);

            cursor.moveToFirst();

            while (cursor != null){

                int id = cursor.getInt(cursor.getColumnIndex(DBHelper.ID));
                String tarefa = cursor.getString(cursor.getColumnIndex(DBHelper.TAREFA));
                String prioridade = cursor.getString(cursor.getColumnIndex(DBHelper.PRIORIDADE));
                String tempo = cursor.getString(cursor.getColumnIndex(DBHelper.TEMPO));

                Tarefa t = new Tarefa(id, tarefa, prioridade, tempo);

                ListaTarefas.addTarefa(t);

                cursor.moveToNext();

            }

            cursor.close();

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public boolean concluirTarefa(int id){

        String where = DBHelper.ID + " = ?";
        String[] args = {String.valueOf(id)};

        long result = gateway.getDataBase().delete(DBHelper.TABELA, where, args);

        if(result > 0){

            return true;
        }

        return false;
    }

    public boolean editarTarefa(Tarefa t){

        String where = DBHelper.ID + " = ?";
        String[] args = {String.valueOf(t.getId())};

        ContentValues values = new ContentValues();

        values.put(DBHelper.TAREFA, t.getTarefa());
        values.put(DBHelper.PRIORIDADE, t.getPrioridade());
        values.put(DBHelper.TEMPO, t.getTempoEstimado());

        long result = gateway.getDataBase().update(
                DBHelper.TABELA, values, where, args);

        if(result >= 0){
            return true;
        }

        return false;
    }


}
