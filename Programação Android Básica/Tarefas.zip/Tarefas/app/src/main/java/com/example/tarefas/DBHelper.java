package com.example.tarefas;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    // constantes que definem nome do banco, tabela e campos
    public static final String DB = "db_tarefas"; // nome do seu banco
    public static final String TABELA = "tb_tarefas"; // nome da sua tabela
    // OS CAMPOS ABAIXO DEVEM TER RELAÇÃO COM O TIPO DE DADO QUE
    // IRÁ SALVAR NA SUA TABELA
    public static final String ID = "id_tarefa"; // sua chave primária
    public static final String TAREFA = "tarefa";
    public static final String PRIORIDADE= "prioridade";
    public static final String TEMPO = "tempo_est";
    public static final int    VERSAO = 1;



    public DBHelper(@Nullable Context context) {
        super(context, DB, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql = "CREATE TABLE IF NOT EXISTS " + TABELA + " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TAREFA + " VARCHAR, " +
                PRIORIDADE + " VARCHAR, " +
                TEMPO + " VARCHAR); ";

        db.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int wVneersion) {
        db.execSQL("DROP TABLE " + TABELA);
        onCreate(db);
    }
}
