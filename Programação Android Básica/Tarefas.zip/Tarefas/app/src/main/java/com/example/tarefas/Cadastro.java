package com.example.tarefas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Cadastro extends AppCompatActivity {

    EditText edtTarefa;
    EditText edtTempo;
    RadioGroup rdgPrioridade;
    Button btnSalvar;
    TextView txtCad;
    String prioridade = "Normal";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edtTarefa     = findViewById(R.id.edtTarefa);
        edtTempo      = findViewById(R.id.edtTempoEstimado);
        rdgPrioridade = findViewById(R.id.rdgPrioridade);
        btnSalvar     = findViewById(R.id.btnSalvar);
        txtCad        = findViewById(R.id.txtCad);

        txtCad.setText("Nova Tarefa");

        // receber uma intent
        Intent intent = getIntent();
        final int index = intent.getIntExtra("index", -1);

        if(index != -1){

            txtCad.setText("Editar Tarefa");

            // chegamos aqui a partir da cadastro activity
            // carregar objeto da lista na posição especificada pelo 'index'
            Tarefa t = ListaTarefas.getTarefa(index);

            // setar texto das Edit Texts com o valor do objeto:
            edtTarefa.setText(t.getTarefa());
            edtTempo.setText(t.getTempoEstimado());

        }



        rdgPrioridade.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                int selected_radio_id = rdgPrioridade.getCheckedRadioButtonId();

                switch (selected_radio_id){

                    case 0:
                        prioridade = "Normal";
                        break;

                    case 1:
                        prioridade = "Urgente";
                }
            }
        });

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String tarefa = edtTarefa.getText().toString();
                String tempo = edtTempo.getText().toString();

                Tarefa t = new Tarefa(0, tarefa, prioridade, tempo);

                TarefasDAO dao = new TarefasDAO(Cadastro.this);

                if(index != -1){

                    int id = ListaTarefas.getTarefa(index).getId();
                    t.setId(id);

                    if(dao.editarTarefa(t)){
                        Toast.makeText(Cadastro.this, "Tarefa editada com sucesso!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Cadastro.this, MainActivity.class));

                    }else{

                        Toast.makeText(Cadastro.this, "Erro ao editar tarefa...", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Cadastro.this, MainActivity.class));

                    }

                }else {

                    if (dao.salverTarefa(t)) {
                        Toast.makeText(Cadastro.this, "Tarefa cadastrada com sucesso!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Cadastro.this, MainActivity.class));

                    } else {

                        Toast.makeText(Cadastro.this, "Erro ao cadastrar tarefa...", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Cadastro.this, MainActivity.class));
                    }

                }

            }
        });


    }
}
