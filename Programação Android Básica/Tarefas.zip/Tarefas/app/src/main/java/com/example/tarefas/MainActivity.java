package com.example.tarefas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    RecyclerView rclTarefas;
    Button btnCadastrar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rclTarefas = findViewById(R.id.rclTarefas);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        if(ListaTarefas.getLista().size() > 0){

            ListaTarefas.getLista().clear();
        }

        TarefasDAO dao = new TarefasDAO(MainActivity.this);

        try{
            // carrega lista através dos dados provenientes do BD
            dao.getTarefas();

        }catch(Exception e){

            e.printStackTrace();
        }


        TarefasAdapter meuAdapter = new TarefasAdapter(MainActivity.this, ListaTarefas.getLista());
        RecyclerView.LayoutManager meuLayout = new LinearLayoutManager(MainActivity.this,
                LinearLayoutManager.VERTICAL, false);

        rclTarefas.setAdapter(meuAdapter);
        rclTarefas.setLayoutManager(meuLayout);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Cadastro.class));
            }
        });
    }
}
