package com.example.tarefas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Detalhes extends AppCompatActivity {

    TextView txtVerTarefa;
    TextView txtVerPrioridade;
    TextView txtVerTempo;
    Button btnConcluir;
    Button btnEditar;
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);

        txtVerTarefa     = findViewById(R.id.txtVerTarefa);
        txtVerPrioridade = findViewById(R.id.txtVerPrioridade);
        txtVerTempo      = findViewById(R.id.txtVerTempoEst);
        btnConcluir      = findViewById(R.id.btnConcluir);
        btnEditar        = findViewById(R.id.btnEditar);

        Intent detalhes = getIntent();
        final int index = detalhes.getIntExtra("index", -1);

        if(index == -1){

            Toast.makeText(this, "Não foi possível carregar detalhes da tarefa...", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
        }else{

            Tarefa t = ListaTarefas.getTarefa(index);

            txtVerTarefa.setText("Tarefa: " + t.getTarefa());
            txtVerPrioridade.setText("Prioridade: " + t.getPrioridade());
            txtVerTempo.setText("Tempo estimado (em horas): " + t.getTempoEstimado());
            id = t.getId();

            btnEditar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent editar = new Intent(Detalhes.this, Cadastro.class);
                    editar.putExtra("index", index);
                    startActivity(editar);
                }
            });


            btnConcluir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    
                    TarefasDAO dao = new TarefasDAO(Detalhes.this);
                    
                    if(dao.concluirTarefa(id)){

                        Toast.makeText(Detalhes.this, "Tarefa concluída!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Detalhes.this, MainActivity.class));

                    }else{

                        Toast.makeText(Detalhes.this, "Não foi possível concluir esta tarefa", Toast.LENGTH_SHORT).show();
                    }
                    
                    
                }
            });


            
            
        }

    }
}
