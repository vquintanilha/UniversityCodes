package com.example.tarefas;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TarefasAdapter extends RecyclerView.Adapter {

    private Context context; // qual o contexto este adaptador será criado?
    private ArrayList<Tarefa> listaTarefas; // qual o dataset (fonte de dados)?

    public TarefasAdapter(Context context, ArrayList<Tarefa> listaTarefas) {
        this.context = context;
        this.listaTarefas = listaTarefas;
        // construtor do adapter recebe estes dois parâmetros e os seta para seus atributos
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // vamos criar elementos de interface "view" que, no caso, serão as células que o RecyclerView
        // irá criar e abrigar. Para tanto, precisamos 'inflar' para dentro do adapter aquele XML
        // responsável por configurar a exibição dos dados de cada célula (que neste caso, é
        // o arquivo celula_tarefa.xml, dentro da pasta res > layout)
        View view = LayoutInflater.from(context).inflate(R.layout.celula_tarefa, parent, false);

        // agora precisamos definir quem é o holder deste adapter:
        TarefasHolder holder = new TarefasHolder(view);

        return holder; // devolvemos o holder criado
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        // para cada atualização das células visiveis no RecyclerView, precisamos
        // automatizar a referencia das células com as informações oriundas da fonte de dados
        // (a lista de tarefas, neste caso)

        // a cada rolagem de tela nos precisamos redefinir o holder, para que o adapter SEMPRE
        // trabalhe com o holder criado anteriormente
        TarefasHolder tHolder = (TarefasHolder)holder;

        // cada célula terá seus valores próprios. É isso que dizemos abaixo:

        String tarefa = listaTarefas.get(position).getTarefa();
        String prioridade = listaTarefas.get(position).getPrioridade();

        tHolder.txtTarefa.setText(tarefa);
        tHolder.txtPrioridade.setText("(" + prioridade + ")");

        // ação de clique no nome da tarefa de cada célula
        tHolder.txtTarefa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // cria uma intent para acessar a activity Detalhes
                Intent detalhes = new Intent(context, Detalhes.class);
                // salva nela a posição na lista do elemento clicado
                detalhes.putExtra("index", position);

                // carrega nova função para a intent:
                detalhes.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                // dispara a intent para nova activity
                context.startActivity(detalhes);
            }
        });


    }

    @Override
    public int getItemCount() {
        return listaTarefas.size();
    }
}
