package com.example.tarefas;

public class Tarefa {

    private int id;
    private String tarefa;
    private String prioridade;
    private  String tempoEstimado;

    public Tarefa(int id, String tarefa, String prioridade, String tempoEstimado) {
        this.id = id;
        this.tarefa = tarefa;
        this.prioridade = prioridade;
        this.tempoEstimado = tempoEstimado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTarefa() {
        return tarefa;
    }

    public void setTarefa(String tarefa) {
        this.tarefa = tarefa;
    }

    public String getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(String prioridade) {
        this.prioridade = prioridade;
    }

    public String getTempoEstimado() {
        return tempoEstimado;
    }

    public void setTempoEstimado(String tempoEstimado) {
        this.tempoEstimado = tempoEstimado;
    }
}
