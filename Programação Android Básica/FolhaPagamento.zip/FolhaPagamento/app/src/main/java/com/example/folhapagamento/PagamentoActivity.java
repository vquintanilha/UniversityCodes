package com.example.folhapagamento;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class PagamentoActivity extends AppCompatActivity {

    TextView txtNome;
    TextView txtHorasTrab;
    TextView txtValorHora;
    TextView txtBruto;
    TextView txtIR;
    TextView txtINSS;
    TextView txtFGTS;
    TextView txtLiquido;
    ImageButton btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagamento);

        txtNome = findViewById(R.id.txtNome);
        txtHorasTrab = findViewById(R.id.txtHorasTrab);
        txtValorHora = findViewById(R.id.txtValorHora);
        txtBruto = findViewById(R.id.txtBruto);
        txtIR = findViewById(R.id.txtIR);
        txtINSS = findViewById(R.id.txtINSS);
        txtFGTS = findViewById(R.id.txtFGTS);
        txtLiquido = findViewById(R.id.txtLiquido);
        btnVoltar = findViewById(R.id.btnVoltar);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        String nome = bundle.getString("nome","");
        Float horasTrab = bundle.getFloat("horasTrab",0);
        Float valorHora = bundle.getFloat("valorHora",0);
        Float Bruto = calcularBruto(horasTrab, valorHora);
        Float IR = calcularIR(Bruto);
        Float INSS = calcularINSS(Bruto);
        Float FGTS = calcularFGTS(Bruto);
        Float Liquido = calcularLiquido(Bruto, IR, INSS);

        String horasTrabForm = String.format(Locale.FRANCE, "%.2f", horasTrab);
        String valorHoraForm = String.format(Locale.FRANCE, "%.2f", valorHora);
        String BrutoForm = String.format(Locale.FRANCE, "%.2f", Bruto);
        String IRForm = String.format(Locale.FRANCE, "%.2f", IR);
        String INSSForm = String.format(Locale.FRANCE, "%.2f", INSS);
        String FGTSForm = String.format(Locale.FRANCE, "%.2f", FGTS);
        String LiquidoForm = String.format(Locale.FRANCE, "%.2f", Liquido);

        txtNome.setText("Nome do funcionário: " + nome);
        txtHorasTrab.setText("Horas trabalhadas: " + horasTrabForm);
        txtValorHora.setText("Valor da hora: " + valorHoraForm);
        txtBruto.setText("Salário bruto: " + BrutoForm);
        txtIR.setText("IR: " + IRForm);
        txtINSS.setText("INSS: " + INSSForm);
        txtFGTS.setText("FGTS: " + FGTSForm);
        txtLiquido.setText("Salário líquido: " + LiquidoForm);

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PagamentoActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }

    public Float calcularBruto(Float horasTrab, Float valorHora){
        return horasTrab * valorHora;
    }

    public Float calcularIR(Float Bruto){
        if (Bruto <= 1372.81f) {
            return 0f;
        }
        else if (Bruto <= 2743.25f) {
            return Bruto * 0.15f;
        }
        return Bruto * 0.275f;
    }

    public Float calcularINSS(Float Bruto){
        if (Bruto <= 868.29f) {
            return Bruto * 0.08f;
        }
        else if (Bruto <= 1447.14f) {
            return Bruto * 0.09f;
        }
        else if (Bruto <= 2894.28f) {
            return Bruto * 0.11f;
        }
        return 318.37f;
    }

    public Float calcularFGTS(Float Bruto){
        return Bruto * 0.08f;
    }

    public Float calcularLiquido(Float Bruto, Float IR, Float INSS){
        return Bruto - IR - INSS;
    }

}
