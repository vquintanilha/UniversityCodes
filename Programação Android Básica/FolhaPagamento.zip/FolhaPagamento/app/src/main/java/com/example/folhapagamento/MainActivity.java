package com.example.folhapagamento;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtNome;
    EditText edtHorasTrab;
    EditText edtValorHora;
    Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNome = findViewById(R.id.edtNome);
        edtHorasTrab = findViewById(R.id.edtHorasTrab);
        edtValorHora = findViewById(R.id.edtValorHora);
        btnCalcular = findViewById(R.id.btnCalcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edtNome.getText().toString().isEmpty() ||
                   edtHorasTrab.getText().toString().isEmpty() ||
                   edtValorHora.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Preencha todos os campos!", Toast.LENGTH_LONG).show();
                }
                else
                {
                    String nome = edtNome.getText().toString();
                    float horasTrab = Float.parseFloat(edtHorasTrab.getText().toString());
                    float valorHora = Float.parseFloat(edtValorHora.getText().toString());

                    Bundle bundle = new Bundle();
                    bundle.putString("nome", nome);
                    bundle.putFloat("horasTrab", horasTrab);
                    bundle.putFloat("valorHora", valorHora);

                    Intent intent = new Intent(MainActivity.this, PagamentoActivity.class);
                    intent.putExtras(bundle);

                    startActivity(intent);

                    closeKeyboard();
                    edtNome.getText().clear();
                    edtHorasTrab.getText().clear();
                    edtValorHora.getText().clear();
                }
            }
        });
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}
