package com.example.cadastroprodutos;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ProdutosHelper extends SQLiteOpenHelper {

    public static final String DB = "db_produtos";
    public static final String TABELA = "tb_produtos";

    public static final String ID = "id_produto";
    public static final String NOME = "nome";
    public static final String CATEGORIA = "categoria";
    public static final String VALOR = "valor";
    public static final int VERSAO = 1;

    public ProdutosHelper(@Nullable Context context) {
        super(context, DB, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE IF NOT EXISTS " + TABELA + " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NOME + " VARCHAR, " +
                CATEGORIA + " VARCHAR, " +
                VALOR + " VARCHAR); ";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE " + TABELA);
        onCreate(db);
    }
}
