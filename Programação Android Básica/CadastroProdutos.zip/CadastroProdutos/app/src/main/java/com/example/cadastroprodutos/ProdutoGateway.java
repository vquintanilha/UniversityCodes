package com.example.cadastroprodutos;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class ProdutoGateway {

    private static ProdutoGateway gateway;
    private SQLiteDatabase db;

    public ProdutoGateway(Context context) {
        ProdutosHelper helper = new ProdutosHelper(context);
        db = helper.getWritableDatabase();
    }

    public static ProdutoGateway getInstance(Context context){
        if(gateway == null){
            gateway = new ProdutoGateway(context);
        }
        return gateway;
    }

    public SQLiteDatabase getDataBase(){
        return this.db;
    }
}
