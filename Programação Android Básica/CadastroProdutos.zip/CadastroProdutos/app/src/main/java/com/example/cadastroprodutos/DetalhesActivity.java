package com.example.cadastroprodutos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DetalhesActivity extends AppCompatActivity {

    TextView txtVerNome;
    TextView txtVerCategoria;
    TextView txtVerValor;
    Button btnEditar;
    Button btnExcluir;
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);

        txtVerNome = findViewById(R.id.txtVerNome);
        txtVerCategoria = findViewById(R.id.txtVerCategoria);
        txtVerValor = findViewById(R.id.txtVerValor);
        btnEditar = findViewById(R.id.btnEditar);
        btnExcluir = findViewById(R.id.btnExcluir);

        Intent detalhes = getIntent();
        final int index = detalhes.getIntExtra("index", -1);

        if(index == -1){
            Toast.makeText(this, "Não foi possível carregar detalhes do produto...", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(DetalhesActivity.this, MainActivity.class));
        }else{
            Produto p = ProdutosLista.getProduto(index);

            txtVerNome.setText("Nome do Produto: " + p.getNome());
            txtVerCategoria.setText("Categoria: " + p.getCategoria());
            txtVerValor.setText("Valor: " + p.getValor());
            id = p.getId();

            btnEditar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent editar = new Intent(DetalhesActivity.this, CadastroActivity.class);
                    editar.putExtra("index", index);
                    startActivity(editar);
                }
            });
            
            btnExcluir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ProdutoDAO dao = new ProdutoDAO(DetalhesActivity.this);
                    
                    if(dao.excluirProduto(id)){
                        Toast.makeText(DetalhesActivity.this, "Produto excluído com sucesso!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(DetalhesActivity.this, MainActivity.class));
                    }else{
                        Toast.makeText(DetalhesActivity.this, "Não foi possível excluir este produto...", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            
        }

    }
}
