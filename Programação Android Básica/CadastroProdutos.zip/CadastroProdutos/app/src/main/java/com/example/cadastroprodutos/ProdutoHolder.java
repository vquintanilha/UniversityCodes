package com.example.cadastroprodutos;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ProdutoHolder extends RecyclerView.ViewHolder {

    TextView txtNome;
    TextView txtCategoria;

    public ProdutoHolder(@NonNull View itemView) {
        super(itemView);
        txtNome = itemView.findViewById(R.id.txtNome);
        txtCategoria = itemView.findViewById(R.id.txtCategoria);
    }
}
