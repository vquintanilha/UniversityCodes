package com.example.cadastroprodutos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;

public class MainActivity extends AppCompatActivity {

    RecyclerView rclProdutos;
    Button btnCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rclProdutos = findViewById(R.id.rclProdutos);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        if(ProdutosLista.getLista().size() > 0){
            ProdutosLista.getLista().clear();
        }

        ProdutoDAO dao = new ProdutoDAO(MainActivity.this);

        try{
            dao.getProdutos();
        }catch (Exception e){
            e.printStackTrace();
        }

        ProdutoAdapter meuAdapter = new ProdutoAdapter(MainActivity.this, ProdutosLista.getLista());
        RecyclerView.LayoutManager meuLayout = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false);

        rclProdutos.setAdapter(meuAdapter);
        rclProdutos.setLayoutManager(meuLayout);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CadastroActivity.class));
            }
        });

    }
}
