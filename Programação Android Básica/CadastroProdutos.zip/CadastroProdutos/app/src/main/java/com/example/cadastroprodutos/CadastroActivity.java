package com.example.cadastroprodutos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CadastroActivity extends AppCompatActivity {

    EditText edtNome;
    EditText edtCategoria;
    EditText edtValor;
    Button btnSalvar;
    TextView txtCad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edtNome = findViewById(R.id.edtNome);
        edtCategoria = findViewById(R.id.edtCategoria);
        edtValor = findViewById(R.id.edtValor);
        btnSalvar = findViewById(R.id.btnSalvar);
        txtCad = findViewById(R.id.txtCad);

        txtCad.setText("Novo Produto");

        Intent intent = getIntent();
        final int index = intent.getIntExtra("index", -1);
        
        if(index != -1){
            txtCad.setText("Editar Tarefa");
            
            Produto p = ProdutosLista.getProduto(index);
            
            edtNome.setText(p.getNome());
            edtCategoria.setText(p.getCategoria());
            edtValor.setText(p.getValor());
        }
        
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                
                String nome = edtNome.getText().toString();
                String categoria = edtCategoria.getText().toString();
                String valor = edtValor.getText().toString();
                
                Produto p = new Produto(0, nome, categoria, valor);
                
                ProdutoDAO dao = new ProdutoDAO(CadastroActivity.this);
                
                if(index != -1){
                    int id = ProdutosLista.getProduto(index).getId();
                    p.setId(id);
                    
                    if(dao.editarProduto(p)){
                        Toast.makeText(CadastroActivity.this, "Produto editado com sucesso!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(CadastroActivity.this, MainActivity.class));
                    }else{
                        Toast.makeText(CadastroActivity.this, "Erro ao editar produto...", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(CadastroActivity.this, MainActivity.class));
                    }
                }else{
                    if(dao.salvarProduto(p)){
                        Toast.makeText(CadastroActivity.this, "Produto cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(CadastroActivity.this, MainActivity.class));
                    }else{
                        Toast.makeText(CadastroActivity.this, "Erro ao cadastrar produto...", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(CadastroActivity.this, MainActivity.class));
                    }
                }
                
            }
        });

    }
}
