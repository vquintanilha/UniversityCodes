package com.example.cadastroprodutos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class ProdutoDAO {

    private ProdutoGateway gateway;

    public ProdutoDAO(Context context){
        this.gateway = ProdutoGateway.getInstance(context);
    }

    public boolean salvarProduto(Produto p){
        ContentValues values = new ContentValues();

        values.put(ProdutosHelper.NOME, p.getNome());
        values.put(ProdutosHelper.CATEGORIA, p.getCategoria());
        values.put(ProdutosHelper.VALOR, p.getValor());

        long result = 0;
        try{
            result = gateway.getDataBase().insert(ProdutosHelper.TABELA, null, values);
        }catch(Exception e){
            e.printStackTrace();
        }

        if(result > 0){
            return true;
        }
        return false;
    }

    public void getProdutos(){
        String sql = "SELECT * FROM " + ProdutosHelper.TABELA;
        try{
            Cursor cursor = gateway.getDataBase().rawQuery(sql, null);
            cursor.moveToFirst();
            while(cursor != null){
                int id = cursor.getInt(cursor.getColumnIndex(ProdutosHelper.ID));
                String nome = cursor.getString(cursor.getColumnIndex(ProdutosHelper.NOME));
                String categoria = cursor.getString(cursor.getColumnIndex(ProdutosHelper.CATEGORIA));
                String valor = cursor.getString(cursor.getColumnIndex(ProdutosHelper.VALOR));

                Produto p = new Produto(id, nome, categoria, valor);
                ProdutosLista.addProduto(p);

                cursor.moveToNext();
            }
            cursor.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public boolean excluirProduto(int id){
        String where = ProdutosHelper.ID + " = ?";
        String[] args = {String.valueOf(id)};

        long result = gateway.getDataBase().delete(ProdutosHelper.TABELA, where, args);

        if(result > 0){
            return true;
        }
        return false;
    }

    public boolean editarProduto(Produto p){
        String where = ProdutosHelper.ID + " = ?";
        String[] args = {String.valueOf(p.getId())};

        ContentValues values = new ContentValues();

        values.put(ProdutosHelper.NOME, p.getNome());
        values.put(ProdutosHelper.CATEGORIA, p.getCategoria());
        values.put(ProdutosHelper.VALOR, p.getValor());

        long result = gateway.getDataBase().update(ProdutosHelper.TABELA, values, where, args);

        if(result > 0){
            return true;
        }
        return false;
    }

}
