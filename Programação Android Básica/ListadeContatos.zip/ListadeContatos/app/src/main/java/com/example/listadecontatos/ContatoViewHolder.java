package com.example.listadecontatos;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ContatoViewHolder extends RecyclerView.ViewHolder {

    TextView txtNome;
    TextView txtFone;
    TextView txtEmail;

    public ContatoViewHolder(@NonNull View itemView) {
        super(itemView);

        txtNome = itemView.findViewById(R.id.txtNome);
        txtFone = itemView.findViewById(R.id.txtFone);
        txtEmail = itemView.findViewById(R.id.txtEmail);

    }
}
