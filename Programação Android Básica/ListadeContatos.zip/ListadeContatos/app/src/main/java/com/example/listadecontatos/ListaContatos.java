package com.example.listadecontatos;

import java.util.ArrayList;

public class ListaContatos {

    private static ArrayList<Contato> listaContatos = new ArrayList<>();

    public static void addContato(Contato c){
        listaContatos.add(c);
    }

    public static ArrayList<Contato> getLista(){
        return listaContatos;
    }

    public static Contato getContato(int index){
        return listaContatos.get(index);
    }

    public static void gerarLista(){
        listaContatos.add(new Contato("João Silva","(41) 91010 9999","jo@o.com"));
        listaContatos.add(new Contato("José Oliveira","(41) 98888 7777","jo@ze.com"));
        listaContatos.add(new Contato("Maria Souza e Silva","(41) 96666 5555","mari@gmail.com"));
        listaContatos.add(new Contato("Fernanda Pereira","(41) 94444 3333","fer@nanda.com"));
        listaContatos.add(new Contato("Carol Silva","(41) 92222 1111","carol@email.com"));
    }

}
