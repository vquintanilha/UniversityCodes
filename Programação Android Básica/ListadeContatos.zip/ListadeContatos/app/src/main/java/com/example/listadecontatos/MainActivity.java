package com.example.listadecontatos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    Button btnAdd;
    RecyclerView rclContatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd = findViewById(R.id.btnAdd);
        rclContatos = findViewById(R.id.rclContatos);

        if(ListaContatos.getLista().size() == 0){
            ListaContatos.gerarLista();
        }

        // criar o adapter para exibir os contatos:
        ContatoAdapter contatoAdapter = new ContatoAdapter(ListaContatos.getLista(), MainActivity.this);

        // setar o adaptador para a recycler view:
        rclContatos.setAdapter(contatoAdapter);

        // definir o layout de exibição
        RecyclerView.LayoutManager meuLayout = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false);

        // setar as configurações de layout para a recycler view
        rclContatos.setLayoutManager(meuLayout);

    }
}
