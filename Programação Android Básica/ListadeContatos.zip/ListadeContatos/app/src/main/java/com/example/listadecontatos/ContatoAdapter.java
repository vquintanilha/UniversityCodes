package com.example.listadecontatos;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;

import java.util.ArrayList;

public class ContatoAdapter extends RecyclerView.Adapter {

    // dois dados fundamentais para o adapter;
    // fonte de dados
    private ArrayList<Contato> listaContatos;
    //contexto
    private Context context;

    public ContatoAdapter(ArrayList<Contato> listaContatos, Context context) {
        this.listaContatos = listaContatos;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // determina o layout de cada celula do holder na view
        // informamos o contexto em que será inserida esta recycler list e
        // qual o arquivo xml responsável pelo layout de cada celula
        // (no nosso exemplo, é o celula.xml)

        View view = LayoutInflater.from(context).inflate(R.layout.celula, viewGroup, false);

        ContatoViewHolder contatoViewHolder = new ContatoViewHolder(view);

        return contatoViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {

        ContatoViewHolder contatoViewHolder = (ContatoViewHolder)viewHolder;
        contatoViewHolder.txtNome.setText(listaContatos.get(i).getNome());
        contatoViewHolder.txtFone.setText(listaContatos.get(i).getFone());
        contatoViewHolder.txtEmail.setText(listaContatos.get(i).getEmail());

    }

    @Override
    public int getItemCount() {
        return listaContatos.size();
    }
}
