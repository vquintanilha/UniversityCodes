package com.example.convertertemperatura;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtTemp;
    Button btnConverter;
    TextView txtF;
    TextView txtK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtTemp = findViewById(R.id.edtTemp);
        btnConverter = findViewById(R.id.btnConverter);
        txtF = findViewById(R.id.txtF);
        txtK = findViewById(R.id.txtK);

        btnConverter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edtTemp.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Informe a temperatura!", Toast.LENGTH_LONG).show();
                } else {
                    float c = Float.parseFloat(edtTemp.getText().toString());

                    float f = (c * 9/5) + 32;
                    float k = c + 273.15f;

                    txtF.setText("Fahrenheit: " + f);
                    txtK.setText("Kelvin: " + k);
                    edtTemp.setText("");
                }
            }
        });
    }
}
