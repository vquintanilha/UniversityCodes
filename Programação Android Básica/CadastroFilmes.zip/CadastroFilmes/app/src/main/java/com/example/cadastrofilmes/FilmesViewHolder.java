package com.example.cadastrofilmes;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class FilmesViewHolder extends RecyclerView.ViewHolder {

    TextView txtTitulo;
    TextView txtAno;

    public FilmesViewHolder(@NonNull View itemView) {
        super(itemView);
        txtTitulo = itemView.findViewById(R.id.txtTitulo);
        txtAno = itemView.findViewById(R.id.txtAno);
    }
}
