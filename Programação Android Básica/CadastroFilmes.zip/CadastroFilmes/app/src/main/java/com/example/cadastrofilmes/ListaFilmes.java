package com.example.cadastrofilmes;

import java.util.ArrayList;

public class ListaFilmes {

    private static ArrayList<Filme> listaFilmes = new ArrayList<>();

    public static void addFilme(Filme f){
        listaFilmes.add(f);
    }

    public static ArrayList<Filme> getLista(){
        return listaFilmes;
    }

    public static Filme getFilme(int index)
    {

        return listaFilmes.get(index);
    }

    /*
    public static void gerarLista(){
        listaFilmes.add(new Filme("Vingadores: Ultimato","2019","Anthony Russo, Joe Russo","Fantasia/Filme de ficção científica"));
        listaFilmes.add(new Filme("Coringa","2019","Todd Phillips","Drama/Suspense"));
        listaFilmes.add(new Filme("Zumbilândia: Atire Duas Vezes","2019","Ruben Fleischer","Filme de zumbi/Ação"));
        listaFilmes.add(new Filme("Harry Potter e a Pedra Filosofal","2001","Chris Columbus","Fantasia/Ficção"));
        listaFilmes.add(new Filme("Percy Jackson e o Ladrão de Raios","2010","Chris Columbus","Fantasia/Aventura"));
    }
     */

}
