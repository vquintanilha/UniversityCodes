package com.example.cadastrofilmes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DetalhesActivity extends AppCompatActivity {

    TextView txtVerTitulo;
    TextView txtVerDiretor;
    TextView txtVerAno;
    TextView txtVerGenero;
    Button   btnEdt;
    Button   btnExcluir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);

        txtVerTitulo  = findViewById(R.id.txtVerTitulo);
        txtVerDiretor = findViewById(R.id.txtVerDiretor);
        txtVerAno     = findViewById(R.id.txtVerAno);
        txtVerGenero  = findViewById(R.id.txtVerGenero);
        btnEdt        = findViewById(R.id.btnEdt);
        btnExcluir    = findViewById(R.id.btnExcluir);

        Intent intent = getIntent();
        int index = intent.getIntExtra("index", -1);

        if(index == -1){
            Toast.makeText(this, "Erro ao carregar detalhes do filme.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(DetalhesActivity.this, MainActivity.class));
        }
        else
        {
            final Filme f = ListaFilmes.getFilme(index);
            txtVerTitulo.setText("Título: " + f.getTitulo());
            txtVerDiretor.setText("Diretor: " + f.getDiretor());
            txtVerAno.setText("Ano: " + f.getAno());
            txtVerGenero.setText("Gênero: " + f.getGenero());

            btnExcluir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    FilmeDAO dao = new FilmeDAO(DetalhesActivity.this);
                    if(dao.excluirFilme(f.getId())){
                        Toast.makeText(DetalhesActivity.this, "Filme excluído com sucesso!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(DetalhesActivity.this, MainActivity.class));
                    }else{
                        Toast.makeText(DetalhesActivity.this, "Erro ao excluir filme...", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

    }
}
