package com.example.cadastrofilmes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnAdd;
    RecyclerView rclFilmes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd = findViewById(R.id.btnAdd);
        rclFilmes = findViewById(R.id.rclFilmes);

        /*
        if(ListaFilmes.getLista().size() == 0){
            ListaFilmes.gerarLista();
        }
        */

        // cada vez que carregar esta activity, devemos limpar
        // a lista local, e carregar os dados do banco, para
        // evitar registros duplicados na lista:
        if(ListaFilmes.getLista().size() > 0){
            ListaFilmes.getLista().clear();
        }

        // cria novo objeto 'dao'
        FilmeDAO dao = new FilmeDAO(MainActivity.this);

        try{
            // carrega lista através dos dados provenientes do BD
            dao.listarFilmes();
        }catch(Exception e){
            e.printStackTrace();
        }

        FilmesAdapter filmesAdapter = new FilmesAdapter(ListaFilmes.getLista(), MainActivity.this);
        RecyclerView.LayoutManager meuLayout = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false);

        rclFilmes.setAdapter(filmesAdapter);
        rclFilmes.setLayoutManager(meuLayout);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CadastroActivity.class));
            }
        });

    }
}
