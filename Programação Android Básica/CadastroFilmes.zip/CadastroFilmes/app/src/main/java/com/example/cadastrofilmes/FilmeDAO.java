package com.example.cadastrofilmes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class FilmeDAO {

    private DBGateway gateway;

    public FilmeDAO(Context context){
        gateway = DBGateway.getInstance(context);
    }

    public boolean salvarFilme(Filme f){
        // Criar ContentValues (similar a um Bundle)
        ContentValues values = new ContentValues();

        // armazenar dados do objeto 'f' no objeto 'values'
        // argumentos: nome do campo, valor a ser salvo
        values.put(DBHelper.TITULO, f.getTitulo());
        values.put(DBHelper.DIRETOR, f.getDiretor());
        values.put(DBHelper.ANO, f.getAno());
        values.put(DBHelper.GENERO, f.getGenero());

        long result = gateway.getDatabase().insert(DBHelper.TABELA, null, values);

        /*
        'result' precisa ser 'long', pois o retorno de um
        comando sql numa base de dados SQLite é sempre 'long'.

        Acessamos nossa conexão com o banco (gateway);
        Recebemos a informação de qual banco estamos
        conectados (getDatabase());
        Informamos que iremos fazer um INSERT INTO em
        alguma tabela do banco recebido:
            O primeiro argumento é o nome da tabela;
            Segundo argumento, por padrão, é null;
            Terceiro argumento são os valores que iremos inserir
            (values).
         */

        if(result > 0){
            return true; // cadastrou com sucesso
        }
        return false; // não foi possível cadastrar
    }

    public void listarFilmes(){
        // criar comando sql
        String sql = "SELECT * FROM " + DBHelper.TABELA;

        // Criar cursor (uma espécie de ponteiro que irá percorrer
        // todos os dados de uma tabela existente no banco de dados
        Cursor cursor = gateway.getDatabase().rawQuery(sql, null);

        try{
            // mover cursor para o inicio da tabela proveniente do SELECT
            cursor.moveToFirst();

            // Enquanto houverem linhas para percorrer na tabela
            while (cursor != null){
                // variáveis locais para receber dados de cada linha
                int id = cursor.getInt(cursor.getColumnIndex(DBHelper.ID));
                String titulo = cursor.getString(cursor.getColumnIndex(DBHelper.TITULO));
                String diretor = cursor.getString(cursor.getColumnIndex(DBHelper.DIRETOR));
                String ano = cursor.getString(cursor.getColumnIndex(DBHelper.ANO));
                String genero = cursor.getString(cursor.getColumnIndex(DBHelper.GENERO));

                // armazenar variaveis locais no objeto 'f'
                Filme f = new Filme(id, titulo, diretor, ano, genero);

                // armazena na lista local:
                ListaFilmes.addFilme(f);

                // mover para proxima linha:
                cursor.moveToNext();
            }// fim 'while'

            // fechar cursor após ter percorrido todos os valores
            cursor.close();

        }catch(Exception e){
            // caso dê algum erro, apontará no LogCat:
            e.printStackTrace();
        }
    }

    public boolean excluirFilme(int id){
        String where = DBHelper.ID + " = ?";
        String[] args = {String.valueOf(id)};

        long result = gateway.getDatabase().delete(DBHelper.TABELA, where, args);

        // DELETE FROM filmes WHERE id = ?(variavel id)

        if(result > 0){
             return true; // excluiu com sucesso
        }
        return false; // erro ao excluir
    }

}
