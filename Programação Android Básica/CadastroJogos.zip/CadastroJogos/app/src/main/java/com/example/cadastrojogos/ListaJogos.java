package com.example.cadastrojogos;

import java.util.ArrayList;

public class ListaJogos {

    private static ArrayList<Jogo> listaJogos = new ArrayList<>();

    // adiciona um jogo na lista
    public static void addJogo(Jogo j){
        listaJogos.add(j);
    }

    // retorna todos os jogos da lista
    public static ArrayList<Jogo> getLista(){
        return listaJogos;
    }

    // retorna um jogo específico da lista
    public static Jogo getJogo(int index){
        return listaJogos.get(index);
    }

    // exclui jogo especifico
    public static void excluirJogo(int index){
        listaJogos.remove(index);
    }

    // gera lista caso não haja nenhum jogo cadastrado
    public static void gerarLista(){
        listaJogos.add(new Jogo("God of War","STE Santa Monica",2018,"PS4"));
        listaJogos.add(new Jogo("Battlefield I","DICE",2016,"PS4 / Xbox One / PC"));
        listaJogos.add(new Jogo("Horizon: Zero Down","Guerrila Games",2017,"PS4"));
    }

}
