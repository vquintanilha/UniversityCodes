package com.example.cadastrojogos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class DetalhesActivity extends AppCompatActivity {

    TextView txtTitulo;
    TextView txtEstudio;
    TextView txtAno;
    TextView txtPlataforma;
    Button btnExcluir;
    int index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);

        txtTitulo = findViewById(R.id.txtTitulo);
        txtEstudio = findViewById(R.id.txtEstudio);
        txtAno = findViewById(R.id.txtAno);
        txtPlataforma = findViewById(R.id.txtPlataforma);
        btnExcluir = findViewById(R.id.btnExcluir);

        // receber a intent da main activity
        Intent carregar = getIntent();
        index = carregar.getIntExtra("index", -1);

        if(index == -1){
            Toast.makeText(this, "Não foi possível carregar os detalhes do jogo!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(DetalhesActivity.this, MainActivity.class));
        }else{
            Jogo j = ListaJogos.getJogo(index);
            txtTitulo.setText("Título: " + j.getTitulo());
            txtEstudio.setText("Estúdio: " + j.getEstudio());
            txtAno.setText("Ano de lançamento: " + j.getAno());
            txtPlataforma.setText("Plataforma(s): " + j.getPlataforma());
            btnExcluir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ListaJogos.excluirJogo(index);
                    Toast.makeText(DetalhesActivity.this, "Jogo excluído com sucesso!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(DetalhesActivity.this, MainActivity.class));
                }
            });
        }

    }
}
