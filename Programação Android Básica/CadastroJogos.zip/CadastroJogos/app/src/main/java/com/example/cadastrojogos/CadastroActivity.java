package com.example.cadastrojogos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroActivity extends AppCompatActivity {

    EditText edtTitulo;
    EditText edtEstudio;
    EditText edtAno;
    EditText edtPlataforma;
    Button btnCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edtTitulo = findViewById(R.id.edtTitulo);
        edtEstudio = findViewById(R.id.edtEstudio);
        edtAno = findViewById(R.id.edtAno);
        edtPlataforma = findViewById(R.id.edtPlataforma);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    String titulo = edtTitulo.getText().toString();
                    String estudio = edtEstudio.getText().toString();
                    int ano = Integer.parseInt(edtAno.getText().toString());
                    String plataforma = edtPlataforma.getText().toString();

                    Jogo j = new Jogo(titulo, estudio, ano, plataforma);
                    ListaJogos.addJogo(j);

                    Toast.makeText(CadastroActivity.this, "Jogo cadastrado com sucesso!", Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(CadastroActivity.this, MainActivity.class));
                }catch (Exception e){
                    Toast.makeText(CadastroActivity.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
