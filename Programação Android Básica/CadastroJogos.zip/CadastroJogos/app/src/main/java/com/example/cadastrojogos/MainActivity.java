package com.example.cadastrojogos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    Button btnAdd;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd = findViewById(R.id.btnAdd);
        listView = findViewById(R.id.listView);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CadastroActivity.class));
            }
        });

        // se ao carregar esta activity verificarmos que
        // não há jogos cadastrados na lista, chamamos o
        // método que gera uma lista genérica de jogos
        if(ListaJogos.getLista().size() == 0){
            ListaJogos.gerarLista();
        }

        // criar um adaptador para carregadar os dados na lista
        /*
        atributos do construtor do adaptador:
        contexto,
        o layout da lista (aqui estamos usando o layout genérico),
        fonte de dados que a lista exibirá
         */
        ArrayAdapter<Jogo> adaptador = new ArrayAdapter<Jogo>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                ListaJogos.getLista()
        );

        // setar adaptador criado acima para nossa list view:
        listView.setAdapter(adaptador);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent carregar = new Intent(MainActivity.this, DetalhesActivity.class);
                carregar.putExtra("index", position);
                startActivity(carregar);
            }
        });

    }
}
