import java.util.ArrayList;

/**
 * Classe onde ser� executado o c�lculo de faturamento.
 * 
 * @author 1829203
 *
 */
public class Faturamento {

	/**
	 * M�todo que realiza o c�lculo de faturamento.
	 * 
	 * @param notas As notas de uma empresa.
	 * @return Valor da soma de todas as notas de uma empresa.
	 */
	public static Double faturamentoEmpresa(ArrayList<NotaFiscal> notas) {
		Double faturamentoTotal = 0d;
		for (NotaFiscal nota : notas) {
			faturamentoTotal += nota.getValor();
		}
		return faturamentoTotal;
	}

}