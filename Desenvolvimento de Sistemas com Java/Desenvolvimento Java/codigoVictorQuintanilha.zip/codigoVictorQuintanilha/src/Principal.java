/**
 * Classe principal da aplica��o.
 * 
 * @author 1829799
 *
 */
public class Principal {

	/**
	 * Executa o m�todo da main.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		/**
		 * Executa o menu principal do sistema.
		 */
		String[] opcoes = { "Empresas", "Notas Fiscais", "Relat�rios" };
		boolean continua = true;
		do {
			int opcao = Console.mostrarMenu(opcoes, "Sistema de Notas", null);
			switch (opcao) {
			case 1:
				menuEmpresa();
				break;

			case 2:
				menuNotaFiscal();
				break;

			case 3:
				menuRelatorios();
				break;

			case -1:
				System.out.println("Saindo do Sistema...");
				continua = false;
				break;
			}
		} while (continua);
	}

	/**
	 * Executa o menu de empresa.
	 */
	private static void menuEmpresa() {
		String[] opcoesMenuEmpresas = { "Cadastrar", "Consultar", "Excluir", "Faturamento" };
		boolean continua = true;
		System.out.println();
		do {
			int opcaoMenuEmpresas = Console.mostrarMenu(opcoesMenuEmpresas, "Empresas", "Voltar");
			switch (opcaoMenuEmpresas) {
			case 1:
				Metodos.criarEmpresa();
				break;

			case 2:
				Metodos.consultaDeEmpresas();
				break;

			case 3:
				Metodos.excluirEmpresa();
				break;

			case 4:
				Metodos.faturamento();
				break;

			case -1:
				System.out.println("Saindo do Sistema...");
				continua = false;
				break;
			}
		} while (continua);
		System.out.println();
	}

	/**
	 * Executa o menu de notas fiscais.
	 */
	private static void menuNotaFiscal() {
		String[] opcoes = { "Emitir", "Consultar", "Cancelar", "Cancelar em Lote" };
		boolean continua = true;
		System.out.println();
		do {
			int opcao = Console.mostrarMenu(opcoes, "Notas Fiscais", "Voltar");
			switch (opcao) {
			case 1:
				Metodos.emitirNotas();
				break;

			case 2:
				Metodos.consultarNotas();
				break;

			case 3:
				Metodos.cancelarNotas();
				break;

			case 4:
				Metodos.cancelarNotasLote();
				break;

			case -1:
				System.out.println("Voltando ao Menu Principal...");
				continua = false;
				break;
			}
		} while (continua);
		System.out.println();
	}

	/**
	 * Executa o menu de relat�rios.
	 */
	private static void menuRelatorios() {
		String[] opcoes = { "Por Empresas", "Notas Canceladas", "Por Valor" };
		boolean continua = true;
		System.out.println();
		do {
			int opcao = Console.mostrarMenu(opcoes, "Relat�rios", "Voltar");
			switch (opcao) {
			case 1:
				Metodos.gerarRelatorioPorEmpresa();
				break;

			case 2:
				Metodos.gerarRelatorioNotasCanceladas();
				break;

			case 3:
				Metodos.gerarRelatorioPorValorDaNota();
				break;

			case -1:
				System.out.println("Voltando ao Menu Principal...");
				continua = false;
				break;
			}
		} while (continua);
		System.out.println();
	}
}